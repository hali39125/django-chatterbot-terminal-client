# Django + ChatterBot Terminal Client

A conversational terminal bot powered by ChatterBot, using Django's ORM and SQLite to store dialogue data.

## Requirements
- Python 3.10–3.14 (Python 3.11 or 3.12 recommended)
- pip, internet access for installation and corpus training

## Installation

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py train_bot
python manage.py chat
```

During chat, enter `quit` or `exit` to finish; Ctrl+C also exits gracefully.

Run `python manage.py train_bot` only once unless you deliberately want to add training examples again. The SQLite database is stored at `db.sqlite3` and excluded from Git.

## Example conversation

```text
Django + ChatterBot Terminal Client
Type 'quit' or 'exit' to leave.
You: Good morning! How are you doing?
Bot: I am doing very well, thank you for asking.
You: You're welcome.
Bot: Do you like hats?
You: quit
Goodbye!
```

*This is an illustrative transcript. ChatterBot answers can vary based on its training and response selection.*

## Source code and repository

Upload all files except `.venv/` and `db.sqlite3` to a GitHub repository. Insert the actual repository URL in the Word submission; this project cannot publish itself to your account.

## Design
- Django settings register `chatterbot.ext.django_chatterbot` and configure SQLite.
- The `chat` management command reads and responds to terminal input.
- The `train_bot` management command trains from English greetings/conversations and customized examples.
- Exceptions for blank input and Ctrl+C/EOF are handled; business logic is split into functions.

## References
- https://docs.chatterbot.us/django/
- https://docs.chatterbot.us/training/
- https://docs.djangoproject.com/
