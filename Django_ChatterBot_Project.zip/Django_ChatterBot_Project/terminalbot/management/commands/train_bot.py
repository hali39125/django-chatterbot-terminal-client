"""Train the chatbot using a corpus and custom conversational examples."""
from django.core.management.base import BaseCommand
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer, ListTrainer


TRAINING_DIALOGUES = [
    ["Good morning! How are you doing?", "I am doing very well, thank you for asking.", "You're welcome.", "Do you like hats?"],
    ["Hello", "Hi there!", "How can I help you?", "You can ask me a question."],
    ["What is your name?", "My name is CampusBuddy."],
    ["What can you do?", "I can have a simple conversation with you."],
    ["Thank you", "You're welcome!"],
    ["Goodbye", "See you later!"],
]


class Command(BaseCommand):
    help = "Train the chatbot with English corpus and custom conversations."

    def handle(self, *args, **options):
        bot = ChatBot(
            "CampusBuddy",
            storage_adapter="chatterbot.storage.DjangoStorageAdapter",
            logic_adapters=["chatterbot.logic.BestMatch"],
        )
        self.stdout.write("Training English greetings and conversations...")
        corpus_trainer = ChatterBotCorpusTrainer(bot)
        corpus_trainer.train(
            "chatterbot.corpus.english.greetings",
            "chatterbot.corpus.english.conversations",
        )
        custom_trainer = ListTrainer(bot)
        for dialogue in TRAINING_DIALOGUES:
            custom_trainer.train(dialogue)
        self.stdout.write(self.style.SUCCESS("Training complete. Run: python manage.py chat"))
