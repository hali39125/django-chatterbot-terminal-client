"""Interactive command line client using ChatterBot with Django storage."""
from django.core.management.base import BaseCommand
from chatterbot import ChatBot


def build_chatbot():
    """Create a bot whose statements persist through the Django ORM."""
    return ChatBot(
        "CampusBuddy",
        storage_adapter="chatterbot.storage.DjangoStorageAdapter",
        logic_adapters=["chatterbot.logic.BestMatch"],
        read_only=True,
    )


class Command(BaseCommand):
    help = "Start an interactive chatbot session in the terminal."

    def handle(self, *args, **options):
        bot = build_chatbot()
        self.stdout.write("Django + ChatterBot Terminal Client")
        self.stdout.write("Type 'quit' or 'exit' to leave.")

        while True:
            try:
                user_message = input("You: ").strip()
            except (KeyboardInterrupt, EOFError):
                self.stdout.write("Goodbye!")
                break

            if user_message.lower() in {"quit", "exit"}:
                self.stdout.write("Goodbye!")
                break
            if not user_message:
                self.stdout.write("Please enter a message.")
                continue

            try:
                reply = bot.get_response(user_message)
            except Exception as exc:
                # Surface a friendly message without printing internal details.
                self.stderr.write(f"Unable to generate a response: {type(exc).__name__}")
                continue
            self.stdout.write(f"Bot: {reply}")
